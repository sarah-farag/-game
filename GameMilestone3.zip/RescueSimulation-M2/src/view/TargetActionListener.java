package view;

import model.people.CitizenState;
import simulation.Address;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TargetActionListener extends JFrame implements ActionListener {
    MainLooksEast e;

    public void setE(MainLooksEast e) {
        this.e = e;
    }

    public void actionPerformed (ActionEvent ae){

    }
}